using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class TriggerScript : MonoBehaviour
{
    //[SerializeField]
    public string Win;
    /*//[SerializeField]
    public int RedScore;
    //[SerializeField]
    public int BlueScore;*/
    [SerializeField]
    protected Camera MainCam;
    [SerializeField]
    protected Rigidbody rb;
    [SerializeField]
    public Text RedText;
    [SerializeField]
    public Text BlueText;
    [SerializeField]
    public Text WinText;
    [SerializeField]
    public Slider SliderRed;
    [SerializeField]
    public Slider SliderBlue;
    [SerializeField]
    public EventSystem es;



    private void OnTriggerEnter(Collider other) //the sinks / pockets
    {
        //check tags to deterimine scores
        if(other.tag  == "Blue")
        {
            SliderBlue.value++; // increase global blue score
            string BScore =  SliderBlue.value.ToString(); // store global blue score
            BlueText.text = BScore; //Display
            other.gameObject.SetActive(false); //Disable the ball that sank
            //other.enabled = false;
        } 
        else if(other.tag == "Red")
        {
            SliderRed.value++; //increase global red score
            string RScore = SliderRed.value.ToString(); // store global red score
            RedText.text = RScore; //Display
            other.gameObject.SetActive(false); //Disable the ball that sank
            //other.enabled = false;
        }
        else if (other.tag == "Black") //winner winner chicken dinner
        {
            if (!(SliderBlue.value == 7) && !(SliderRed.value == 7)) //have NOT sunk all your balls first
            {
                Win = "GAME OVER, whoever sank the black ball... You lose!";//Display
                WinText.text = Win;
            }
            else if (SliderRed.value == 7) //have sunk all your (Red) balls first
            {
                Win = "Red WINS!!!!!";//Display
                WinText.text = Win;
            }
            else if (SliderBlue.value == 7) ////have sunk all your (Blue) balls first
            {
                Win = "Blue WINS!!!!";//Display
                WinText.text = Win;
            }
            other.gameObject.SetActive(false); //Disable the ball that sank
            //Stop interaction
            //es.enabled = false;
            rb.velocity = new Vector3(0,0,0);
            rb.gameObject.SetActive(false); //Disable cue ball
        }
        else if (other.tag == "White")
        {
            //reset cue ball
            rb.Sleep();
            rb.velocity = new Vector3(0, 0, 0);
            other.transform.position = new Vector3(-1, -0.45f, 0);
            rb.WakeUp();

            /*GameObject CueBall = GameObject.Find("CueBall");
            CueBall.SetActive(false);
            WaitForSecondsRealtime wait = new WaitForSecondsRealtime(1);
            CueBall.SetActive(true);*/
        }
        
    }
}
