using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class DragHandler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [SerializeField]
    protected Camera mainCam;
    [SerializeField]
    protected Rigidbody rd;
    [SerializeField]
    float forceMultiplier;
    [SerializeField]
    EventSystem es;
    [SerializeField]
    LineRenderer line;
    //[SerializeField]
    //GameObject lineObj;
    Vector3 startLine;
    Vector3 endLine;

    public void OnBeginDrag(PointerEventData eventData)
    {
        //initialize start line and make line renderer visible
        line.enabled = true;
        startLine = rd.gameObject.transform.position;
    }
    public void OnDrag(PointerEventData eventData)
    {
        //get the vector to use in AddForce()
        var pos = mainCam.ScreenToWorldPoint(eventData.position);
        pos.y = 0;//-0.45f;
        Vector3 vecToCueBall = transform.position - pos;
        vecToCueBall.y = 0f;
        //Debug.Log("Direction: " + vecToCueBall.normalized + "--- and Magnitude: " + vecToCueBall.magnitude); //helper

        //line.transform.eulerAngles = vecToCueBall.normalized;
        //line.transform.localScale = vecToCueBall;
        //startLine = rd.transform.position; //+ new Vector3 (1,0,0);

        //raycast
        Vector3 Origin = startLine;
        Vector3 direction = vecToCueBall.normalized;
        RaycastHit HitInfo;
        bool RayHitter = Physics.Raycast(Origin, direction, out HitInfo);


        //GameObject EmptyGObj = GameObject.Find("EmptyGObj"); //child
        //EmptyGObj.transform.position = pos;

        //if the ray hits a ball, the end of the line renderer will point to the ball, if not it will simply point to the mouse position
        if (RayHitter) 
        {
            if (HitInfo.transform.tag == "Blue" || HitInfo.transform.tag == "Red" || HitInfo.transform.tag == "Black")
            {
                endLine = HitInfo.transform.position;
            }
            else
            {
                endLine = pos;
            }
        }
        
            //= pos;
        //=EmptyGObj.transform.localPosition*-1;
        //=transform.InverseTransformPoint(EmptyGObj.transform.position)*-1;
        //=transform.TransformPoint(transform.position) - pos;
        //endLine.y = 0;

        //final settings for the line renderer - updating while draging
        line.transform.eulerAngles = new Vector3(0, 0, 0);
        line.transform.localScale = vecToCueBall;
        line.SetPosition(0,startLine);
        line.SetPosition(1, endLine);
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        var pos = mainCam.ScreenToWorldPoint(eventData.position);
        pos.y = 0;//-0.45f;
        Vector3 vecToCueBall = transform.position - pos;
        vecToCueBall.y = 0f;

        //move the cue ball in opposite direction in which the mouse was draged ON END DRAG
        rd.AddForce(vecToCueBall * forceMultiplier, ForceMode.Impulse);

        //Debug.Log("Direction: " + vecToCueBall.normalized + "--- and Magnitude: " + vecToCueBall.magnitude); //helper
        //line.transform.localScale = new Vector3(0, 0, 0);

        //make invisible
        line.enabled = false;

        //lineObj.SetActive(true);
        //lineObj.transform.eulerAngles = vecToCueBall.normalized*90;
        //lineObj.transform.localScale.z. = vecToCueBall.magnitude;
    }

    public void Update()
    {
        //Debug.Log(rd.velocity);

        //check if player ball is moving on each frame
        if (!(rd.velocity == new Vector3(0, 0, 0))) //stop input while moving
        {
            es.enabled = false;
        } 
        else
        {
            es.enabled = true;
        }

        if (rd.gameObject.transform.position.y < -1)//knocked off the table (in case of failure with bumper-colliders)
        {
            //reset cue ball
            rd.Sleep();
            rd.velocity = new Vector3(0, 0, 0);
            rd.gameObject.transform.position = new Vector3(-1, -0.45f, 0);
            rd.WakeUp();
        }
    }

    public void Start()
    {
        // line renderer starts as invisible
        line.enabled = false;
    }

}
